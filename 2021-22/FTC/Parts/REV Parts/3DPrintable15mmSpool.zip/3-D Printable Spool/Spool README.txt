﻿3D Printed Spool Instructions

The Spool fits on a 5mm Hex shaft. A hole exists on the drum to allow the user to tie string to it without slipping.
Tie the string so that it wraps around the drum.

The spool model uses global variables for its length and diameter. These can be changed in the equations folder of the SolidWorks Part:

1. Right Click on "Equations" folder in the feature tree on the left side of the screen  
2. Select "Manage Equations"
3. In the popup, you can change the value for the overall length and drum diameter in by editing the table  
4. Close out of the popup by clicking "OK"
5. Model dimensions will update  

Printing Suggestions:
   * Printed with PETG on a Prusa MK3S. Other filaments and printers would also work.
   * 20% infill or higher.
   * Wall thickness was increased to four filament layers for increased strength.