**READ ME**
This document contains information regarding the parts in this zip file. You will need a motor to mount the UltraPlanetary to for your CAD assembly.

M3X10 is used with output stage only assemblies
M3X20 is used with one stage assemblies
M3X30 is used with two stage assemblies
M3X40 is used with three stage assemblies

REV-41-1601, REV-41-1602, and REV-41-1603 are the Cartridges
REV-41-1604 is the output stage
REV-41-1607 is the input plate
REV-41-1608 is the input pinion for your motor.

UltraPlanetary works with any 550 class motor such as:
REV-41-1291 - HD Hex Motor
REV-21-1651 - NEO 550 Brushless Motor